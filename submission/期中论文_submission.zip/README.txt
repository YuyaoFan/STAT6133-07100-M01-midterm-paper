期中论文提交包（Canvas）
========================

题目：工资的年龄曲线：参数、非参数与半参数回归方法的比较研究
课程：《非参和半参回归》期中论文

提交内容
  1. 论文.pdf                 论文 PDF（12 页，含数据来源、方法、结论讨论、参考文献、AI 工具使用说明）
  2. code/                    全部 Python 代码、数据、依赖清单与预生成结果
       analysis.py            主分析脚本（参数 / 非参数 / 半参数方法）
       make_paper.py          论文 PDF 自动排版
       make_slides.py         3 分钟演讲幻灯片与讲稿
       make_video.py          可选：合成演讲视频
       requirements.txt       Python 依赖
       data/Wage.csv          清洗后的公开数据
       data/SOURCES.md        数据来源与清洗说明
       results/               预生成的表格、图形与 results.json

复现方法
  python3 -m pip install -r code/requirements.txt
  python3 code/analysis.py
  python3 code/make_paper.py

数据来源：ISLR::Wage（Mid-Atlantic Wage Data），Rdatasets 公开镜像；
原始整理自 2011 年 3 月 CPS 补充调查。详见 code/data/SOURCES.md 与论文第 2 节。

AI 工具使用说明见论文第 6 节。
